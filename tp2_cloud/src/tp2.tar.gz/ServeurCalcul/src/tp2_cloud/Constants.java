package tp2_cloud;
class Constants {

    static final int MOD_VALUE = 4000;
    static final int MAX_REFUSAL_RATE = 100;
    static final String PELL = "prime";
    static final String MODE_SECURISE = "SECURISE";

}
